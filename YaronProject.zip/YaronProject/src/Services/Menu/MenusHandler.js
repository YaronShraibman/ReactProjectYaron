import React from "react";
import ROUTES from "../../RouterModel";

const about = {
    to: ROUTES.ABOUT,
    label: "About"

}
const cards = {
    to: ROUTES.CARDS,
    label: "Cards"

}

const registration = {
    to: ROUTES.REGISTRATION,
    label: "Registration"

}
const signIn = {
    to: ROUTES.SIGNIN,
    label: "Sign In"

}
const signOut = {
    to: ROUTES.HOME,
    label: "Sign Out"

}
const myCards = {
    to: ROUTES.MYCARDS,
    label: "My Cards"

}
const favCards = {
    to: ROUTES.FAVCARDS,
    label: "Favorite Cards"
}

export const guestMenu = [about,cards,registration,signIn];
export const simpleMenu = [about,favCards,cards,signOut];
export const businessMenu = [about,cards,myCards,favCards,signOut];
