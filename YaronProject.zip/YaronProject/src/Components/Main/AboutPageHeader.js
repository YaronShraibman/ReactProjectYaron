import React from "react";

export function AboutPageHeader() {
    return (
        <>
            <div className={'mt-5'}>
                <h1>About Us</h1>
                <h2>On this page you can find explanations about using the application</h2>
                <hr/>
            </div>
        </>
    )
}