import React from "react";
import "../../Styles/Style.css"


export function Footer() {
    return (
        <>
            <h6 className={"footer"}>© 2013 Yaron Shraibman.  All rights reserved. </h6>
        </>
    )
}
