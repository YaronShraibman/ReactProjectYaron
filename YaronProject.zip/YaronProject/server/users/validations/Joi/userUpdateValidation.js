const userUpdateValidation = user => {
  const newUser = { ...user };
  return newUser;
};

module.exports = userUpdateValidation;
